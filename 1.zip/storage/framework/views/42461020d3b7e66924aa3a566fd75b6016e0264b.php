<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wiwitan Baru</title>
    <link href='https://fonts.googleapis.com/css?family=Nunito:400,300' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/main.css">
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet" type="text/css" />
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\wiwitanbaru\resources\views/layouts/main_layout.blade.php ENDPATH**/ ?>