<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Data</title>
    <style>
        table {
            width: 100%;
        }
        table, th, td {
            border: 1px solid black;
        }
    </style>
</head>
<body>
<table>
    <thead>
        <th>Nama</th>
        <th>Tempat Lahir</th>
        <th>Tanggal Lahir</th>
        <th>Golongan Darah</th>
        <th>Alamat</th>
        <th>Pendidikan Terakhir</th>
        <th>No Telp</th>
        <th>Email</th>
        <th>Konfirmasi</th>
        <th>Ijazah/Rapor</th>
        <th>Essay</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $registed_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->nama); ?></td>
                <td><?php echo e($user->tempat_lahir); ?></td>
                <td><?php echo e($user->tanggal_lahir); ?></td>
                <td><?php echo e($user->golongan_darah); ?></td>
                <td><?php echo e($user->alamat); ?></td>
                <td><?php echo e($user->pendidikan_terakhir); ?></td>
                <td><?php echo e($user->nomor_telp); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->konfirmasi); ?></td>
                <td><a href="<?php echo e(route('download_ijazah', ['fileName' => $user->scan_ijazah])); ?>">Download</a></td>
                <td><a href="<?php echo e(route('download_essay', ['fileName' => $user->essay])); ?>">Download</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</body>
</html><?php /**PATH C:\laragon\www\wiwitanbaru\resources\views/view_data.blade.php ENDPATH**/ ?>